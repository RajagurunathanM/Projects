package com.example.currencyconvertor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.math.*;


public class MainActivity extends AppCompatActivity {

    public void convertFunction(View view)
    {
        EditText cash = (EditText) findViewById(R.id.money);

        long val = Long.parseLong(cash.getText().toString());

        double f = Double.valueOf(val);

        f = f / 75.8474;

        String s = String.valueOf(f);

        s = String.format("%.3f",f);

        Toast.makeText(this, "$"+s, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
